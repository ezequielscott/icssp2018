Replication Package

Contents:

- .zip archive with all the issues with story points for each of the 8 open source JIRA projects. 
- 4 csv files with the resulting accuracy and MMRE metrics across all the projects, one for each tested classifier.*

*reported metrics for the classifiers KNN, Gaussian Naive Bayes, and Decision Tree are computed by using the default classifier parameters configuration given by the sklearn library.
